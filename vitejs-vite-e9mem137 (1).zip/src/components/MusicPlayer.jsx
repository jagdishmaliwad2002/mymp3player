import React, { useState, useEffect, useRef } from 'react';
import { Offcanvas, Modal, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './MusicPlayer.css';

const MusicPlayer = () => {
  // Sample playlist for demo
  const playlist = [
    { title: "Midnight City", artist: "M83", album: "Hurry Up, We're Dreaming", duration: 156, cover: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80" },
    { title: "Demo DoDo", artist: "Synth", album: "Loop Beats", duration: 90, cover: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80" },
    { title: "Calm Night", artist: "LoFi", album: "Chill", duration: 210, cover: "https://images.unsplash.com/photo-1504805572947-34fad45aed93?auto=format&fit=crop&w=800&q=80" }
  ];

  // State management
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const [showAllTracksModal, setShowAllTracksModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [filteredTracks, setFilteredTracks] = useState(playlist);

  // Refs
  const rafId = useRef(null);
  const lastTimestamp = useRef(null);
  const simulatedCurrent = useRef(0);

  // Format time function
  const formatTime = (s) => {
    s = Math.max(0, Math.floor(s || 0));
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return m + ':' + (sec < 10 ? '0' + sec : sec);
  };

  // Update progress UI
  const updateProgressUI = (current, dur) => {
    const pct = dur > 0 ? (current / dur) * 100 : 0;
    const fillPct = Math.max(0, Math.min(100, pct));
    setCurrentTime(current);
    
    // Update aria attributes
    const seekBar = document.getElementById('seekBar');
    if (seekBar) {
      seekBar.setAttribute('aria-valuenow', Math.round(current));
    }
  };

  // Load track
  const loadTrack = (index) => {
    index = (index + playlist.length) % playlist.length;
    setCurrentIndex(index);
    simulatedCurrent.current = 0;
    updateProgressUI(0, playlist[index].duration || 0);
  };

  // Start simulated playback
  const startSimulated = () => {
    cancelAnimationFrame(rafId.current);
    lastTimestamp.current = performance.now();

    const loop = (now) => {
      if (!isPlaying) {
        lastTimestamp.current = now;
        rafId.current = requestAnimationFrame(loop);
        return;
      }

      const delta = (now - lastTimestamp.current) / 1000;
      lastTimestamp.current = now;
      simulatedCurrent.current += delta;
      const dur = playlist[currentIndex].duration || 0;

      if (simulatedCurrent.current >= dur) {
        simulatedCurrent.current = dur;
        updateProgressUI(simulatedCurrent.current, dur);
        setIsPlaying(false);
        return;
      }

      updateProgressUI(simulatedCurrent.current, dur);
      rafId.current = requestAnimationFrame(loop);
    };

    rafId.current = requestAnimationFrame(loop);
  };

  // Stop simulated playback
  const stopSimulated = () => {
    cancelAnimationFrame(rafId.current);
    lastTimestamp.current = null;
  };

  // Handle play/pause
  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  // Handle next track
  const nextTrack = () => {
    loadTrack((currentIndex + 1) % playlist.length);
    setIsPlaying(false);
  };

  // Handle previous track
  const prevTrack = () => {
    loadTrack((currentIndex - 1 + playlist.length) % playlist.length);
    setIsPlaying(false);
  };

  // Handle seek bar click
  const handleSeek = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const pct = Math.max(0, Math.min(1, x / rect.width));
    const dur = playlist[currentIndex].duration || 0;
    const target = pct * dur;
    simulatedCurrent.current = target;
    updateProgressUI(target, dur);
  };

  // Render all tracks
  const renderAllTracks = () => {
    setFilteredTracks(playlist);
  };

  // Render new tracks (short ones)
  const renderNewTracks = () => {
    setFilteredTracks(playlist.filter(t => (t.duration || 0) < 120));
  };

  // Highlight active track
  const highlightActive = (index) => {
    return index === currentIndex ? 'active' : '';
  };

  // Escape HTML function
  const escapeHtml = (s) => {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  };

  // Effects
  useEffect(() => {
    if (isPlaying) {
      startSimulated();
    } else {
      stopSimulated();
    }

    return () => {
      cancelAnimationFrame(rafId.current);
    };
  }, [isPlaying]);

  useEffect(() => {
    renderAllTracks();
  }, []);

  // Current track
  const currentTrack = playlist[currentIndex] || {};

  return (
    <div className="stage">
      <div className="glass-card">
        <button className="menu-dot" type="button" onClick={() => setShowOffcanvas(true)} title="Tracks">
          <i className="fa-solid fa-ellipsis-vertical" style={{ color: '#fff' }}></i>
        </button>

        <div className="visual mx-auto">
          <img id="coverImg" src={currentTrack.cover} alt="cover" />
        </div>
        <div className="title">
          <h3 id="songTitle">{currentTrack.title}</h3>
          <p id="songMeta">{currentTrack.artist} — {currentTrack.album}</p>
        </div>

        {/* GLASSY SEEK (no thumb) */}
        <div className="seek-wrap">
          <div 
            className="seek" 
            id="seekBar" 
            role="progressbar" 
            aria-valuemin="0" 
            aria-valuemax={currentTrack.duration || 0} 
            aria-valuenow={currentTime}
            onClick={handleSeek}
          >
            <div 
              className="progress" 
              id="progress"
              style={{ width: `${(currentTime / (currentTrack.duration || 1)) * 100}%` }}
            ></div>
          </div>
          <div className="times">
            <div id="curTime">{formatTime(currentTime)}</div>
            <div id="durTime">{formatTime(currentTrack.duration)}</div>
          </div>
        </div>

        <div className="controls">
          <div className="left-icons">
            <button className="icon-btn" id="shuffle" title="Shuffle">
              <i className="fa-solid fa-shuffle"></i>
            </button>
            <button className="icon-btn" id="prev" title="Previous" onClick={prevTrack}>
              <i className="fa-solid fa-backward-step"></i>
            </button>
          </div>

          <div className="center-control">
            <button className="play-btn" id="playBtn" aria-pressed={isPlaying} title="Play / Pause" onClick={togglePlay}>
              <div className="play-inner" id="playInner">
                <i className={`fa-solid ${isPlaying ? 'fa-pause' : 'fa-play'}`}></i>
              </div>
            </button>
          </div>

          <div className="right-icons">
            <button className="icon-btn" id="next" title="Next" onClick={nextTrack}>
              <i className="fa-solid fa-forward-step"></i>
            </button>
            <button className="icon-btn" id="repeat" title="Repeat">
              <i className="fa-solid fa-repeat"></i>
            </button>
          </div>
        </div>
      </div>

      {/* Developer Credit (VISIBLE below the card) */}
      <div className="developer-credit">
        © 2025 · Dreamed 🎶 Designed 💻 Developed ❤️ by 
        <a href="#" target="_blank">Jagdish Maliwad</a>
      </div>

      {/* Offcanvas simplified */}
      <Offcanvas show={showOffcanvas} onHide={() => setShowOffcanvas(false)} placement="start" className="text-light">
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Tracks</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body className="pb-5">
          <div className="row-card" role="button" onClick={() => { setShowOffcanvas(false); setShowAllTracksModal(true); renderAllTracks(); }}>
            <div>
              <div className="label">All songs</div>
              <div className="meta">View every track</div>
            </div>
            <div><i className="fa-solid fa-chevron-right" style={{ color: '#fff' }}></i></div>
          </div>
          <div className="row-card" role="button" onClick={() => { setShowOffcanvas(false); setShowAllTracksModal(true); renderNewTracks(); }}>
            <div>
              <div className="label">New songs</div>
              <div className="meta">Recently added</div>
            </div>
            <div><i className="fa-solid fa-chevron-right" style={{ color: '#fff' }}></i></div>
          </div>
          <div className="row-card" role="button" onClick={() => { setShowOffcanvas(false); setShowAllTracksModal(true); renderAllTracks(); }}>
            <div>
              <div className="label">Artists</div>
              <div className="meta">Browse by artist</div>
            </div>
            <div><i className="fa-solid fa-chevron-right" style={{ color: '#fff' }}></i></div>
          </div>

          <div className="mt-2">
            <Button variant="outline-light" size="sm" className="w-100" onClick={() => { setShowAllTracksModal(true); renderAllTracks(); }}>
              Open All Tracks
            </Button>
          </div>

          <div className="offcanvas-footer">
            <button className="login-btn" onClick={() => setShowLoginModal(true)}>
              <i className="fa-solid fa-user-lock me-2"></i>Login
            </button>
          </div>
        </Offcanvas.Body>
      </Offcanvas>

      {/* All Tracks modal (glass overlay) */}
      <Modal show={showAllTracksModal} onHide={() => setShowAllTracksModal(false)} fullscreen>
        <Modal.Header closeButton>
          <Modal.Title>All Tracks</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p className="small text-muted">Tap any track to play it.</p>
          <div className="track-grid">
            {filteredTracks.map((track, index) => (
              <div 
                key={index} 
                className={`track-card ${highlightActive(index)}`}
                onClick={() => {
                  loadTrack(index);
                  setIsPlaying(true);
                  setShowAllTracksModal(false);
                }}
              >
                <div className="d-flex gap-2 align-items-center">
                  <img src={track.cover} style={{ width: '56px', height: '56px', borderRadius: '8px', objectFit: 'cover' }} alt={track.title} />
                  <div style={{ flex: 1 }}>
                    <div className="title">{track.title}</div>
                    <div className="meta">{track.artist} — {track.album}</div>
                  </div>
                  <div className="duration">{formatTime(track.duration || 0)}</div>
                </div>
              </div>
            ))}
          </div>
        </Modal.Body>
      </Modal>

      {/* Login modal */}
      <Modal show={showLoginModal} onHide={() => setShowLoginModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Login</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="mb-2">
            <input className="form-control" id="loginEmail" placeholder="Email" />
          </div>
          <div className="mb-2">
            <input className="form-control" id="loginPass" placeholder="Password" type="password" />
          </div>
          <div className="d-grid">
            <button className="btn btn-outline-light" onClick={() => { alert('Demo login — add real auth flow here.'); setShowLoginModal(false); }}>
              Sign In
            </button>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default MusicPlayer;